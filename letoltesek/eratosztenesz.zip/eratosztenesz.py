import math
import os

os.system('color FF')
"""
Kezdünk egy adatbekérdezéssel --> 
Ellenőrzés(Ellenőrzött adatbevitel alias:"BKK") --> 
Listák és változók
Táblázat kiíró rész
"""

"""bekérdezés"""
BKK = False
intervallum = input("Kérem adja meg meddig vizsgáljuk a prím számokat! A választható opciók [100], [121], [144], [169], [196], [225]: ")
szam = intervallum.isdecimal()
intervallum = int(intervallum)
if szam and (intervallum == 100 or intervallum == 121 or intervallum == 144 or intervallum == 169 or intervallum == 196 or intervallum == 225):
    BKK = True
while not BKK and not szam:
    intervallum = int(input("\033[1;31;40m Elnézést rossz számot adott meg, vagy nem is számot! ""\033[1;37;40mKérem adja meg újra, meddig vizsgáljuk a prím számokat! A választható opciók [100], [121], [144], [169], [196], [225]: "))
    if intervallum == 100 or intervallum == 121 or intervallum == 144 or intervallum == 169 or intervallum == 196 or intervallum == 225:
        BKK = True


"""Prím lista"""
primszamok = [0] * (intervallum + 1)


""" változók """
hatvany = int(math.sqrt(intervallum))
sorhossz = 4 * hatvany
horizontalis = "-"
vertikalis = "|"
lst = [True] * (intervallum + 1)
feher = "\033[1;37;40m"
piros = "\033[1;31;40m"
zold = "\033[1;32;40m"
kinkajou = True

""" sorválasztó ciklusa """
for a in range(1, sorhossz + 1):
    horizontalis += "-"

""" színes lista """
szines = ["\033[1;37;40m{:3d}"] * (intervallum+1)

"""prímes lista"""
lst2 = [True] * (hatvany + 1)           # az első sorból kerülnek ki a prímek amikkel szoroznunk kell
szorzoprim = [0] * (hatvany + 2)
for db in range(2, hatvany + 1):
    if lst2[db]:
        for z in range(db * db, hatvany + 1, db):
            lst2[z] = False
for i in range(2, hatvany + 1):
    if lst2[i]:
        szorzoprim[i] = i
legnagyprimszor = 0             #legnagyobb prím amivel majd szorozni kell
for cfg in range(2, hatvany + 1):
    if szorzoprim[cfg] > legnagyprimszor:
        legnagyprimszor = szorzoprim[cfg]

""" táblázat ciklusa """
kiiras = 1
while kiiras != legnagyprimszor + 1:                                                                                    #ennyiszer kell hogy fusson a ciklus hogy minden táblázat kiíródjon
    if kiiras == 1 or kiiras == szorzoprim[kiiras] or legnagyprimszor == kiiras:                                        #ez dönti el mikor lehet táblázat kiírás
        if kiiras == szorzoprim[kiiras] and kiiras != legnagyprimszor:                                                  #ez írja ki hpgy minke a szorzatait vettük le
            print("A(z)" + zold + "{:3d}".format(kiiras) + feher + " szorzatait vettük le.")
        elif kiiras == legnagyprimszor:                                                                                 #a legutolsó táblázat kiírásához kell
            print("A(z)" + zold + "{:3d}".format(kiiras) + feher + " szorzatait vettük le. És a többi már a prím számok csak.")
        print(feher + horizontalis)
        for b in range(1, hatvany + 1):                                                                                 # annyiszor fut le amennyi a hatvány (hatvány == sorok számával == oszlopok számával)
            if b == 1:                                                                                                  #első sor kiíratása
                print(feher+"    ", end=vertikalis)
                for c in range(2, hatvany + 1):
                    print(szines[c].format(c), end=vertikalis)
                print(feher)
                print(feher + horizontalis)

            else:                                                                                                       #a többi sor kiíratása
                hatar = hatvany * b
                print(feher, end=vertikalis)
                for c in range(c + 1, hatar + 1):
                    print(szines[c].format(c), end=vertikalis)
                print(feher)
                print(feher + horizontalis)
        print(feher)
                                   #léptetés
        if kinkajou:
            bekeres1 = False
            tovabb = input(feher + "Tovább szeretne e menni a következő Táblázatra [igen, nem]: ")
            if tovabb == "igen" or tovabb == "nem":
                bekeres1 = True
            elif tovabb == "kinkajou":                      #titkos mikkentyű
                kinkajou = False
                bekeres1 = True
            while not bekeres1:
                tovabb = input(piros+ " Elnézést nem értettem mit szeretne!"+ feher + " Tovább szeretne e menni a következő Táblázatra [igen, nem]: ")
                if tovabb == "igen" or tovabb == "nem":
                    bekeres1 = True
            if tovabb == "nem":
                quit()

    kiiras += 1
    if lst[kiiras]:                                                                                                     #kihúzott számok listába tárolása
        primszamok[kiiras] = kiiras                                                                                     #prím számok tárolása
        szines[kiiras] = zold + "{:3d}"
        for j in range(kiiras * kiiras, intervallum + 1, kiiras):
            lst[j] = False
            szines[j] = piros + "{:3d}"
    if legnagyprimszor == kiiras:       #összes prím tárolása
        for i in range(2, intervallum):
            if lst[i]:
                primszamok[i] = i
                szines[i] = zold + "{:3d}"
""" táblázat ciklusának vége """
print("Nincs tovább")
