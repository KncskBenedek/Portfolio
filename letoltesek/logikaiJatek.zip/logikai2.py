import metodusok
import os

os.system('color FF')


print("""
A játékban oszlopokból kell leemelni elemeket majd egy másik oszlopba helyezni őket!
Az elemeket csak ugyan olyan elemekre lehet tenni.
Az oszlopok megadásához a kívánt oszlopok számát kell majd megadni balról-jobra(1-2-3-4)!
Jó szórakozás! :)
""")
jatek = True
while jatek:
    gyozelem = False
    palyaLista = metodusok.palyaKeszites()
    metodusok.palyaKiiras(palyaLista)
    if metodusok.lehetKirakni():
        while not gyozelem:

            honnan, hova = metodusok.honnanHovaBekeres()
            hely = metodusok.kapacitas(hova, palyaLista)
            if hely:
                milyenSzam = metodusok.vanEszam(hova, palyaLista)
                kiszedett = metodusok.kiszedes(palyaLista, honnan, milyenSzam)
                if kiszedett is not None:
                    metodusok.berakas(kiszedett, palyaLista, hova)

            else:
                print("Nem Letséges művelet.")
            metodusok.palyaKiiras(palyaLista)

            if metodusok.gyozelemEllenorzo(palyaLista):
                gyozelem = True
            if not gyozelem:
                if not metodusok.lehetKirakni():
                    break
        if gyozelem:
            print("Gratulálunk Sikeresen végigjátszottad a játékot! :)")
    jatek = metodusok.ujJatekBekeres()
quit()
