def gyozelemEllenorzo(lista):
    for oszlop in range(0, 4):
        oszlopUtolsoIndexe = ((oszlop+1) * 3) -1
        oszlopElsoIndexe = oszlopUtolsoIndexe - 2
        oszlopKozepsoIndexe = oszlopUtolsoIndexe - 1
        elsoSzam = lista[oszlopElsoIndexe]
        masodikSzam = lista[oszlopKozepsoIndexe]
        harmadikSzam = lista[oszlopUtolsoIndexe]
        if masodikSzam and harmadikSzam != elsoSzam:
            return False
    return True


def berakas(berakando, lista, hovaOszlop):
    oszlopUtolsoIndexe = (hovaOszlop * 3) - 1
    oszlopElsoIndexe = oszlopUtolsoIndexe - 3
    for elem in range(oszlopUtolsoIndexe, oszlopElsoIndexe, -1):
        if lista[elem] == 0:
            lista[elem] = berakando
            break


def kapacitas(hovaOszlop, lista):
    oszlopUtolsoIndexe = (hovaOszlop * 3) - 1
    oszlopElsoIndexe = oszlopUtolsoIndexe - 3
    for elem in range(oszlopUtolsoIndexe, oszlopElsoIndexe, -1):
        if lista[elem] == 0:
            return True
    return False


def vanEszam(hovaOszlop, lista):
    oszlopUtolsoIndexe = (hovaOszlop * 3) - 1
    oszlopElsoIndexe = oszlopUtolsoIndexe - 3
    szam = 0
    for elem in range(oszlopUtolsoIndexe, oszlopElsoIndexe, -1):
        if lista[elem] > 0:
            szam = lista[elem]
    return szam


def kiszedes(lista, honnanOszlop, szam):
    voltNulla = False
    kiszedettElem = 0
    kiszedIndex = -1
    oszlopUtolsoIndexe = (honnanOszlop * 3) - 1
    oszlopElsoIndexe = oszlopUtolsoIndexe-3
    hiba = False
    if lista[oszlopUtolsoIndexe] == 0:
        hiba = True
    if not hiba:
        for elem in range(oszlopUtolsoIndexe, oszlopElsoIndexe, -1):
            kiszedIndex = elem
            kiszedettElem = lista[kiszedIndex]

            if kiszedettElem == 0:
                kiszedettElem = lista[kiszedIndex + 1]
                if szam != 0:
                    if kiszedettElem != szam:
                        return None
                lista[kiszedIndex + 1] = 0
                voltNulla = True
                break
        if szam != 0:
            if szam != kiszedettElem:
                return None
        if not voltNulla:
            lista[kiszedIndex] = 0
    return kiszedettElem


def darabEllenorzes(szamDBLista, elemLista, maxDB):
    valtozo = False
    if szamDBLista[0] == maxDB:
        if 1 in elemLista:
            elemLista.remove(1)
            valtozo = True
    if szamDBLista[1] == maxDB:
        if 2 in elemLista:
            elemLista.remove(2)
            valtozo = True
    if szamDBLista[2] == maxDB:
        if 3 in elemLista:
            elemLista.remove(3)
            valtozo = True
    if len(elemLista) == 2:
        valtozo = True
    if len(elemLista) == 1:
        valtozo = True
    if valtozo:
        return True
    return False


def palyaKeszites():
    import random

    lista = [0]*12
    maxSzam = 3
    szamok = [1, 2, 3]
    szamdb = [0, 0, 0]
    for elem in range(0, 9):

        if not darabEllenorzes(szamdb, szamok, 3):
            randomszam = random.randint(1, maxSzam)
            lista[elem] = randomszam
            if randomszam == 1:
                szamdb[0] += 1
            if randomszam == 2:
                szamdb[1] += 1
            if randomszam == 3:
                szamdb[2] += 1
        elif len(szamok) == 2:
            randomszam = random.randint(1, maxSzam - 1)
            nagyobb = szamok[1]
            kissebb = szamok[0]
            if randomszam == 2:
                lista[elem] = nagyobb
                szamdb[nagyobb-1] += 1
            else:
                lista[elem] = kissebb
                szamdb[kissebb-1] += 1
        else:
            lista[elem] = szamok[0]
    return lista


def honnanHovaBekeres():
    honnan = input("Kérem adja meg melyik oszlopból kíván levenni! (1-4): ")

    while (not honnan.isnumeric()) or int(honnan) < 1 or int(honnan) > 4:
        honnan = input("Rossz oszlopot/nem létező oszlopot adott meg kérkük adja meg újra!")

    honnan = int(honnan)

    hova = input("Kérem adja meg melyik oszlopba kívánja betenni majd az elemet! (1-4): ")
    while (not hova.isnumeric()) or int(hova) < 1 or int(hova) > 4:
        hova = input("Rossz oszlopot/nem létező oszlopot adott meg kérkük adja meg újra!")

    hova = int(hova)
    return honnan, hova


def palyaKiiras(lista):
    for i in range(0, 3):
        if lista[i] == 0:
            print("| |", end=" ")
        else:
            print("|{}|".format(lista[i]), end=" ")
        for n in range(i + 3, i + 10, 3):
            if lista[n] == 0:
                print("| |", end=" ")
            else:
                print("|{}|".format(lista[n]), end=" ")
        print(" ")


def ujJatekBekeres():
    jatek = input("Szeretne még játszani? Ha igen írja be 1 || ha nem irja be 2:")

    while (not jatek.isnumeric()) or int(jatek) < 1 or int(jatek) > 2:
        jatek = input("Rossz adatot adott meg!\nSzeretne még játszani? Ha igen írja be 1 || ha nem irja be 2:")

    if jatek == "1":
        return True
    else:
        return False


def lehetKirakni():
    lehetEkirakni = input("Amennyiben nem tudja befejezni/nem lehetséges kirakni a játékot írjon be egy 1-est || egyébként 0-át: ")
    while (not lehetEkirakni.isnumeric()) or int(lehetEkirakni) < 0 or int(lehetEkirakni) > 1:
        lehetEkirakni = input("Amennyiben nem tudja befejezni/nem lehetséges kirakni a játékot írjon be egy 1-est || egyébként 0-át: ")
    if lehetEkirakni == "1":
        return False
    return True
